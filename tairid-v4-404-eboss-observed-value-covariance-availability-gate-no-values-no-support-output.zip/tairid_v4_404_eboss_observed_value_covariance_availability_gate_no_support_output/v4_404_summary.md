# v4.404 eBOSS observed-value and covariance availability gate

Expected result: `v4_404_eboss_observed_value_covariance_availability_gate_passed_source_family_available_no_values_no_support_claims`

Rules: 65 / 65

Failed gates: `none`

This gate confirms source-family availability for eBOSS LRG, ELG, and QSO and creates the exact-source locator packet for v4.405. It does not load observed values, covariance values, likelihoods, p-values, scores, or support claims.
