# TAIRID v4.327 SDSS RSD Human Decision Fill Guide — No Scoring

This packet is a fill guide only. It does not approve parameter values, approve numeric baselines, load observed SDSS RSD values, compute residuals, score TAIRID, or make support claims.

Truth boundary: no observed scoring; no parameter approval; no numeric baseline approval; no support claims.

Allowed human decisions for each row:

```text
select_candidate_for_later_value_review
needs_better_source
reject_all
keep_blocked
```

## param_q001 — omega_m0

Review question: What exact source-backed Omega_m0 / matter-density parameter may be used in the later dry-run calculator?

Candidate source rows to review:

- Candidate ID: `parameter_source_candidate_001`
  - Candidate class: `omega_m_source_context`
  - Source URL: https://arxiv.org/abs/1807.06209
  - Quote/context window: 18 results. VI. Cosmological parameters, by Planck Collaboration: N. Aghanim and 180 other authors View PDF Abstract: We present cosmological parameter results from the final full-mission Planck measurements of the CMB anisotropies. We find good consistency with the standard spatially-flat 6-parameter $\Lambda$CDM cosmology having a power-law spectrum of adiabatic scalar perturbations (denoted "base $\Lambda$CDM" in this paper), from polarization, temperature, and lensing, separately and in combination. A combined analysis gives dark matter density $\Omega_c h^2 = 0.120\pm 0.001$, baryon density $\Omega_b h^2 = 0.0224\pm 0.0001$, scalar spectral index $n_s = 0.965\pm 0.004$, and optical depth $\tau = 0.054\pm 0.007$ (in this abstract we quote $68\,\%$ confidence regions on measured parameters and $95\,\%$ on upper limits). The angular acoustic scale is measured to $0.03\,\%$ precision, w

- Candidate ID: `parameter_source_candidate_004`
  - Candidate class: `lcdm_parameter_context`
  - Source URL: https://arxiv.org/abs/1807.06209
  - Quote/context window: [1807.06209] Planck 2018 results. VI. Cosmological parameters Skip to main content Learn about arXiv becoming an independent nonprofit. We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors. Donate > astro-ph > arXiv:1807.06209 Help | Advanced Search All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text Search open search GO open navigation menu quick links Login Help Pages Abo

- Candidate ID: `parameter_source_candidate_010`
  - Candidate class: `lcdm_parameter_context`
  - Source URL: https://arxiv.org/abs/1807.06210
  - Quote/context window: [1807.06210] Planck 2018 results. VIII. Gravitational lensing Skip to main content Learn about arXiv becoming an independent nonprofit. We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors. Donate > astro-ph > arXiv:1807.06210 Help | Advanced Search All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text Search open search GO open navigation menu quick links Login Help Pages Abo

- Candidate ID: `parameter_source_candidate_016`
  - Candidate class: `lcdm_parameter_context`
  - Source URL: https://arxiv.org/abs/2007.08991
  - Quote/context window: $, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of temperature and polarization the BAO data provide nearly an order of magnitude improvement on curvature constraints. The RSD measurements indicate a growth rate that is consistent with predictions from Planck primary data and with General Relativity. When combining the results of SDSS BAO and RSD with 

Decision row to fill later:

```text
human_decision =
human_selected_candidate_ids =
human_answer_summary_no_values =
reviewer_note =
```

## param_q002 — sigma8_0

Review question: What exact source-backed sigma8_0 or equivalent normalization may be used in the later dry-run calculator?

Candidate source rows to review:

- Candidate ID: `parameter_source_candidate_004`
  - Candidate class: `lcdm_parameter_context`
  - Source URL: https://arxiv.org/abs/1807.06209
  - Quote/context window: [1807.06209] Planck 2018 results. VI. Cosmological parameters Skip to main content Learn about arXiv becoming an independent nonprofit. We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors. Donate > astro-ph > arXiv:1807.06209 Help | Advanced Search All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text Search open search GO open navigation menu quick links Login Help Pages Abo

- Candidate ID: `parameter_source_candidate_010`
  - Candidate class: `lcdm_parameter_context`
  - Source URL: https://arxiv.org/abs/1807.06210
  - Quote/context window: [1807.06210] Planck 2018 results. VIII. Gravitational lensing Skip to main content Learn about arXiv becoming an independent nonprofit. We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors. Donate > astro-ph > arXiv:1807.06210 Help | Advanced Search All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text Search open search GO open navigation menu quick links Login Help Pages Abo

- Candidate ID: `parameter_source_candidate_016`
  - Candidate class: `lcdm_parameter_context`
  - Source URL: https://arxiv.org/abs/2007.08991
  - Quote/context window: $, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of temperature and polarization the BAO data provide nearly an order of magnitude improvement on curvature constraints. The RSD measurements indicate a growth rate that is consistent with predictions from Planck primary data and with General Relativity. When combining the results of SDSS BAO and RSD with 

- Candidate ID: `parameter_source_candidate_034`
  - Candidate class: `lcdm_parameter_context`
  - Source URL: https://arxiv.org/abs/0704.0944
  - Quote/context window: astro-ph > arXiv:0704.0944 Help | Advanced Search All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text Search GO quick links Login Help Pages About --> Astrophysics arXiv:0704.0944 (astro-ph) [Submitted on 7 Apr 2007] Title: GLAST and Dark Matter Substructure in the Milky Way Authors: Michael Kuhlen (1), Jürg Diemand (2), Piero Madau (2, 3) ((1) Institute for Advanced Study, Princeton, (2) UC Santa Cruz, (3) Max-Planck-Institut für Astrophysik, Garching, Germany) View a PDF of the paper titled GLAST and Dark Matter Substructure in the Milky Way, by Michael Kuhlen (1) and 7 other authors View PDF Abstract: We discuss the possibility of GLAST detecting gamma-rays from the annihilation of neutralino dark matter in the Galactic halo. We have used "Via Lactea", currently 

Decision row to fill later:

```text
human_decision =
human_selected_candidate_ids =
human_answer_summary_no_values =
reviewer_note =
```

## param_q003 — growth_index_gamma

Review question: What source or method justifies gamma = 0.55 or another growth-index approximation?

Candidate source rows to review:

- Candidate ID: `parameter_source_candidate_012`
  - Candidate class: `calculator_limit_context`
  - Source URL: https://arxiv.org/abs/1807.06210
  - Quote/context window: llaboration: N. Aghanim and 156 other authors View PDF Abstract: We present measurements of the cosmic microwave background (CMB) lensing potential using the final $\textit{Planck}$ 2018 temperature and polarization data. We increase the significance of the detection of lensing in the polarization maps from $5\,\sigma$ to $9\,\sigma$. Combined with temperature, lensing is detected at $40\,\sigma$. We present an extensive set of tests of the robustness of the lensing-potential power spectrum, and construct a minimum-variance estimator likelihood over lensing multipoles $8 \le L \le 400$. We find good consistency between lensing constraints and the results from the $\textit{Planck}$ CMB power spectra within the $\rm{\Lambda CDM}$ model. Combined with baryon density and other weak priors, the lensing analysis alone constrains $\sigma_8 \Omega_{\rm m}^{0.25}=0.589\pm 0.020$ ($1\,\sigma$ erro

- Candidate ID: `parameter_source_candidate_015`
  - Candidate class: `growth_index_method_context`
  - Source URL: https://arxiv.org/abs/2007.08991
  - Quote/context window: l) Abstract: We present the cosmological implications from final measurements of clustering using galaxies, quasars, and Ly$\alpha$ forests from the completed Sloan Digital Sky Survey (SDSS) lineage of experiments in large-scale structure. These experiments, composed of data from SDSS, SDSS-II, BOSS, and eBOSS, offer independent measurements of baryon acoustic oscillation (BAO) measurements of angular-diameter distances and Hubble distances relative to the sound horizon, $r_d$, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than 

- Candidate ID: `parameter_source_candidate_018`
  - Candidate class: `calculator_limit_context`
  - Source URL: https://arxiv.org/abs/2007.08991
  - Quote/context window: he most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of temperature and polarization the BAO data provide nearly an order of magnitude improvement on curvature constraints. The RSD measurements indicate a growth rate that is consistent with predictions from Planck primary data and with General Relativity. When combining the results of SDSS BAO and RSD with external data, all multiple-parameter extensions remain consistent with a $\Lambda$CDM model. Regardless of cosmological model, the precision on $\Omega_\Lambda$

- Candidate ID: `parameter_source_candidate_024`
  - Candidate class: `calculator_limit_context`
  - Source URL: https://arxiv.org/abs/2007.08997
  - Quote/context window: i-tracer mock catalogues with redshift evolution and systematics for galaxies and quasars of the final data release, by Cheng Zhao and 20 other authors View PDF Abstract: We produce 1000 realizations of synthetic clustering catalogues for each type of the tracers used for the baryon acoustic oscillation and redshift space distortion analysis of the Sloan Digital Sky Surveys-IV extended Baryon Oscillation Spectroscopic Survey final data release (eBOSS DR16), covering the redshift range from 0.6 to 2.2, to provide reliable estimates of covariance matrices and test the robustness of the analysis pipeline with respect to observational systematics. By extending the Zel'dovich approximation density field with an effective tracer bias model calibrated with the clustering measurements from the observational data, we accurately reproduce the two- and three-point clustering statistics of the eBOSS

Decision row to fill later:

```text
human_decision =
human_selected_candidate_ids =
human_answer_summary_no_values =
reviewer_note =
```

## param_q004 — lcdm_calculator_context

Review question: What standard-Lambda-CDM calculator context is allowed for the dry-run comparator?

Candidate source rows to review:

- Candidate ID: `parameter_source_candidate_004`
  - Candidate class: `lcdm_parameter_context`
  - Source URL: https://arxiv.org/abs/1807.06209
  - Quote/context window: [1807.06209] Planck 2018 results. VI. Cosmological parameters Skip to main content Learn about arXiv becoming an independent nonprofit. We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors. Donate > astro-ph > arXiv:1807.06209 Help | Advanced Search All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text Search open search GO open navigation menu quick links Login Help Pages Abo

- Candidate ID: `parameter_source_candidate_010`
  - Candidate class: `lcdm_parameter_context`
  - Source URL: https://arxiv.org/abs/1807.06210
  - Quote/context window: [1807.06210] Planck 2018 results. VIII. Gravitational lensing Skip to main content Learn about arXiv becoming an independent nonprofit. We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors. Donate > astro-ph > arXiv:1807.06210 Help | Advanced Search All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text Search open search GO open navigation menu quick links Login Help Pages Abo

- Candidate ID: `parameter_source_candidate_015`
  - Candidate class: `growth_index_method_context`
  - Source URL: https://arxiv.org/abs/2007.08991
  - Quote/context window: l) Abstract: We present the cosmological implications from final measurements of clustering using galaxies, quasars, and Ly$\alpha$ forests from the completed Sloan Digital Sky Survey (SDSS) lineage of experiments in large-scale structure. These experiments, composed of data from SDSS, SDSS-II, BOSS, and eBOSS, offer independent measurements of baryon acoustic oscillation (BAO) measurements of angular-diameter distances and Hubble distances relative to the sound horizon, $r_d$, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than 

- Candidate ID: `parameter_source_candidate_016`
  - Candidate class: `lcdm_parameter_context`
  - Source URL: https://arxiv.org/abs/2007.08991
  - Quote/context window: $, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of temperature and polarization the BAO data provide nearly an order of magnitude improvement on curvature constraints. The RSD measurements indicate a growth rate that is consistent with predictions from Planck primary data and with General Relativity. When combining the results of SDSS BAO and RSD with 

Decision row to fill later:

```text
human_decision =
human_selected_candidate_ids =
human_answer_summary_no_values =
reviewer_note =
```

## param_q005 — rsd_definition_bridge

Review question: What source ties the parameter calculator output to f_sigma8 / RSD comparison language?

Candidate source rows to review:

- Candidate ID: `parameter_source_candidate_015`
  - Candidate class: `growth_index_method_context`
  - Source URL: https://arxiv.org/abs/2007.08991
  - Quote/context window: l) Abstract: We present the cosmological implications from final measurements of clustering using galaxies, quasars, and Ly$\alpha$ forests from the completed Sloan Digital Sky Survey (SDSS) lineage of experiments in large-scale structure. These experiments, composed of data from SDSS, SDSS-II, BOSS, and eBOSS, offer independent measurements of baryon acoustic oscillation (BAO) measurements of angular-diameter distances and Hubble distances relative to the sound horizon, $r_d$, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than 

- Candidate ID: `parameter_source_candidate_017`
  - Candidate class: `rsd_growth_context`
  - Source URL: https://arxiv.org/abs/2007.08991
  - Quote/context window: implications from final measurements of clustering using galaxies, quasars, and Ly$\alpha$ forests from the completed Sloan Digital Sky Survey (SDSS) lineage of experiments in large-scale structure. These experiments, composed of data from SDSS, SDSS-II, BOSS, and eBOSS, offer independent measurements of baryon acoustic oscillation (BAO) measurements of angular-diameter distances and Hubble distances relative to the sound horizon, $r_d$, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension

- Candidate ID: `parameter_source_candidate_027`
  - Candidate class: `growth_index_method_context`
  - Source URL: https://arxiv.org/abs/astro-ph/0507263
  - Quote/context window: energy density contents, while the cosmic growth history tests the evolution of the inhomogeneous part of the energy density. Precision comparison of the two histories can distinguish the nature of the physics responsible for the accelerating cosmic expansion: an additional smooth component - dark energy - or a modification of the gravitational field equations. With the aid of a new fitting formula for linear perturbation growth accurate to 0.05-0.2%, we separate out the growth dependence on the expansion history and introduce a new growth index parameter \gamma that quantifies the gravitational modification. Comments: 8 pages, 3 figures; minor changes to match version accepted to PRD Subjects: Astrophysics (astro-ph) ; General Relativity and Quantum Cosmology (gr-qc) Cite as: arXiv:astro-ph/0507263   (or arXiv:astro-ph/0507263v2 for this version)   https://doi.org/10.48550/arXiv.astro-p

- Candidate ID: `parameter_source_candidate_033`
  - Candidate class: `growth_index_method_context`
  - Source URL: https://arxiv.org/abs/0704.0944
  - Quote/context window: links Login Help Pages About --> Astrophysics arXiv:0704.0944 (astro-ph) [Submitted on 7 Apr 2007] Title: GLAST and Dark Matter Substructure in the Milky Way Authors: Michael Kuhlen (1), Jürg Diemand (2), Piero Madau (2, 3) ((1) Institute for Advanced Study, Princeton, (2) UC Santa Cruz, (3) Max-Planck-Institut für Astrophysik, Garching, Germany) View a PDF of the paper titled GLAST and Dark Matter Substructure in the Milky Way, by Michael Kuhlen (1) and 7 other authors View PDF Abstract: We discuss the possibility of GLAST detecting gamma-rays from the annihilation of neutralino dark matter in the Galactic halo. We have used "Via Lactea", currently the highest resolution simulation of Galactic cold dark matter substructure, to quantify the contribution of subhalos to the annihilation signal. We present a simulated allsky map of the expected gamma-ray counts from dark matter annihilation

Decision row to fill later:

```text
human_decision =
human_selected_candidate_ids =
human_answer_summary_no_values =
reviewer_note =
```

## param_q006 — calculator_limit_policy

Review question: What limits must remain around growth-index approximation, covariance, likelihood, and model-comparison claims?

Candidate source rows to review:

- Candidate ID: `parameter_source_candidate_012`
  - Candidate class: `calculator_limit_context`
  - Source URL: https://arxiv.org/abs/1807.06210
  - Quote/context window: llaboration: N. Aghanim and 156 other authors View PDF Abstract: We present measurements of the cosmic microwave background (CMB) lensing potential using the final $\textit{Planck}$ 2018 temperature and polarization data. We increase the significance of the detection of lensing in the polarization maps from $5\,\sigma$ to $9\,\sigma$. Combined with temperature, lensing is detected at $40\,\sigma$. We present an extensive set of tests of the robustness of the lensing-potential power spectrum, and construct a minimum-variance estimator likelihood over lensing multipoles $8 \le L \le 400$. We find good consistency between lensing constraints and the results from the $\textit{Planck}$ CMB power spectra within the $\rm{\Lambda CDM}$ model. Combined with baryon density and other weak priors, the lensing analysis alone constrains $\sigma_8 \Omega_{\rm m}^{0.25}=0.589\pm 0.020$ ($1\,\sigma$ erro

- Candidate ID: `parameter_source_candidate_018`
  - Candidate class: `calculator_limit_context`
  - Source URL: https://arxiv.org/abs/2007.08991
  - Quote/context window: he most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of temperature and polarization the BAO data provide nearly an order of magnitude improvement on curvature constraints. The RSD measurements indicate a growth rate that is consistent with predictions from Planck primary data and with General Relativity. When combining the results of SDSS BAO and RSD with external data, all multiple-parameter extensions remain consistent with a $\Lambda$CDM model. Regardless of cosmological model, the precision on $\Omega_\Lambda$

- Candidate ID: `parameter_source_candidate_024`
  - Candidate class: `calculator_limit_context`
  - Source URL: https://arxiv.org/abs/2007.08997
  - Quote/context window: i-tracer mock catalogues with redshift evolution and systematics for galaxies and quasars of the final data release, by Cheng Zhao and 20 other authors View PDF Abstract: We produce 1000 realizations of synthetic clustering catalogues for each type of the tracers used for the baryon acoustic oscillation and redshift space distortion analysis of the Sloan Digital Sky Surveys-IV extended Baryon Oscillation Spectroscopic Survey final data release (eBOSS DR16), covering the redshift range from 0.6 to 2.2, to provide reliable estimates of covariance matrices and test the robustness of the analysis pipeline with respect to observational systematics. By extending the Zel'dovich approximation density field with an effective tracer bias model calibrated with the clustering measurements from the observational data, we accurately reproduce the two- and three-point clustering statistics of the eBOSS

- Candidate ID: `parameter_source_candidate_042`
  - Candidate class: `calculator_limit_context`
  - Source URL: https://www.sdss4.org/science/final-bao-and-rsd-measurements/
  - Quote/context window: t were installed at the 2.5 meter Sloan Telescope in 2009. The BOSS design and survey strategy are described in the 2009-2014 BOSS overview while the eBOSS scientific justification and survey plan are described in the 2014-2019 eBOSS overview . Key to the BAO and RSD measurements in SDSS, BOSS, and eBOSS are advanced processing of imaging data, carefully crafted target selection, well vetted catalogs of redshifts, weights, and randoms, clustering analysis, and assessment of statistical and systematic errors through mock catalogs. The likelihoods, covariance matrices, and cosmoMC chains with the SDSS data can be found here . The background of these measurements for each of the SDSS cosmology samples can be found in the table below. The table below may be cut off in your browser, so we also have a full-width version of the table . Parameter Main Galaxy Sample (MGS) BOSS Galaxy BOSS Galaxy 

Decision row to fill later:

```text
human_decision =
human_selected_candidate_ids =
human_answer_summary_no_values =
reviewer_note =
```
