# v4.350 Human-Filled Schema Review Packet for v4.351

Decision: `needs_manual_column_mapping`.

Reason: v4.350 found one high-priority candidate file, `sdss_rsd_manual_answers_v4_300-1.csv`, but the header probe shows it is a manual answer/citation file rather than a direct observed-value table. It does not safely expose redshift, observed fσ8, uncertainty, or covariance columns.

Boundary: no observed values loaded, no definition/covariance match confirmed, no scoring, no support claims.
