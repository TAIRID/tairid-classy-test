# Human-filled v4.371 exact covariance source review for v4.372

This packet fills the v4.371 human exact-source review conservatively.

Two official BOSS/SDSS source directions are marked `needs_web_source_search` because the current repository candidates are not exact covariance matrices.

Repository workflow/output/helper files are rejected as exact covariance files.

Manual upload placeholders remain blocked until an exact covariance file is uploaded.

No covariance file is approved.
No covariance file is staged.
No covariance values are loaded.
No covariance dimensions are confirmed.
No observed-row order is matched.
No likelihood, p-values, score, or support claims are allowed.
