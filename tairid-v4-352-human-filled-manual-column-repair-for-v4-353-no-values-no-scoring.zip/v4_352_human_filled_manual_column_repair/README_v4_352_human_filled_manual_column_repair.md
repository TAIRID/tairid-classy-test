# Human-filled v4.352 manual observed column repair packet

Decision: provide_better_source_file.

Reason: the current candidate is a manual answer/citation table, not a direct observed SDSS RSD value table. It should be used for source tracing only. Observed values remain unloaded. No scoring. No support claims.
