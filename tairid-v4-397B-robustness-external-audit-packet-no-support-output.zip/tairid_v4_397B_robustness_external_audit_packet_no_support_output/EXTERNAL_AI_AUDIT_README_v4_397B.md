# TAIRID v4.397B External AI Audit Packet — Robustness Comparison, No Support Claims

## Truth boundary

robustness external audit packet only; primary and alternate full-covariance chi-square dry-run comparison may be audited; no new chi-square computed; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims

## Key values to audit

prior_guarded_diagonal_chi_square_sum = 1.362038876169214

primary_dM_Hz_chi_square_dry_run_sum = 1.384804886905097

final_consensus_dV_FAP_chi_square = 1.384804886905097

fs_consensus_chi_square = 1.2298323467773977

robustness_min_chi_square = 1.2298323467773977

robustness_max_chi_square = 1.384804886905097

robustness_chi_square_range_width = 0.15497254012769934

alternate_chi_square_rows = 3

primary_plus_alternate_comparison_rows = 4

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

## Strongest allowed conclusion

A robustness comparison chi-square dry run was computed for the primary dM_Hz_fsig covariance candidate and the preserved alternate covariance candidates. The dry-run chi-square values remain within a narrow band from 1.2298323467773977 to 1.384804886905097, with range width 0.15497254012769934. This is audit-ready, but it is not a likelihood, not a p-value, not a validated score, and not a support claim.

## Strongest honest criticism

This remains a guarded three-row BOSS DR12 diagnostic and robustness comparison. It does not use a full likelihood, does not compute p-values, does not validate score_valid, does not permit support claims, and does not yet include broader observed-source families or a multi-survey covariance model.

## External audit request

Please audit whether the packet preserves the truth boundary, whether the reported robustness comparison values are internally consistent, and whether any file improperly claims support.
