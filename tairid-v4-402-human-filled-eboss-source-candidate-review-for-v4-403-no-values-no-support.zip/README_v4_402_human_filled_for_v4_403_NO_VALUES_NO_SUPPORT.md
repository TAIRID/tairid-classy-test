TAIRID v4.402 human-filled eBOSS source candidate review for v4.403

Decision: approve LRG, ELG, and QSO for accepted-source staging only.

Boundary: no observed values loaded, no covariance values loaded, no chi-square, no likelihood, no p-values, score_valid=false, support_allowed=false.
