# TAIRID v4.389 Full-Covariance Chi-Square Dry Run — No Support Claims

Expected result: `v4_389_full_covariance_chi_square_dry_run_passed_no_likelihood_no_p_values_no_support_claims`

54 / 54 rules passed

failed_gates = none

approved_observable_family = `dM_Hz_fsig`

approved_subblock_value_rows = 9

residual_vector_rows = 3

degrees_of_freedom_candidate = 3

prior_guarded_diagonal_chi_square_sum = 1.362038876169214

full_covariance_chi_square_dry_run_sum = 1.384804886905097

full_minus_diagonal_chi_square_difference = 0.022766010735883135

full_to_diagonal_chi_square_ratio = 1.0167146556050686

covariance_subblock_values_loaded = true

full_9x9_covariance_values_loaded = false

full_covariance_chi_square_computed = true

chi_square_computed = true

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: full-covariance chi-square dry run only using the approved 3x3 f_sigma8 covariance subblock; chi-square may be computed for diagnostic comparison; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step computes a full-covariance chi-square dry run using the approved 3x3 f_sigma8 covariance subblock.

It does **not** compute likelihood or p-values.

It does **not** validate a score.

It does **not** make support claims.

Next route: `v4_390_external_ai_audit_packet_covariance_corrected_diagnostic_no_support_claims`
