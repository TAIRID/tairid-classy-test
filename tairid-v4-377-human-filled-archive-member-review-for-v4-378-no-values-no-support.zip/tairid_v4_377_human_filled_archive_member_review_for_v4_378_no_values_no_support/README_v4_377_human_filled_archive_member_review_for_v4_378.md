# Human-filled v4.377 archive member review for v4.378

This review selects only consensus covariance-like archive members for later header-only/member-preview staging.

No archive member contents are read here.
No covariance values are loaded here.
No covariance dimension or observed-row order match is confirmed here.
No likelihood, p-values, score, or support claim is allowed here.

Selected for later header-only staging:
- final_consensus_covtot_dM_Hz_fsig.txt
- final_consensus_covtot_dV_FAP_fsig.txt
- FS_consensus_covtot_dM_Hz_fsig.txt
- FS_consensus_covtot_dV_FAP_fsig.txt

Other candidates are rejected or kept blocked as fallback.
