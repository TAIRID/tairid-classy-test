# Human-filled v4.379 shape-preview review for v4.380

All four selected archive members are approved only for later dimension/order review because v4.379 found rectangular 9x9 shape metadata.

This does not approve an exact covariance member.
This does not load covariance values.
This does not confirm covariance dimensions against observed rows.
This does not match observed row order.
This does not compute likelihood or p-values.
This does not create a valid score.
This does not allow support claims.
