# TAIRID v4.377 Controlled Official Source Download / Archive Listing Attempt — No Values, No Support Claims

Expected result: `v4_377_controlled_source_download_archive_listing_attempt_passed_no_values_no_support_claims`

44 / 44 rules passed

failed_gates = none

controlled_attempt_rows = 2

download_attempted = true

source_files_fetched = 2

archive_or_header_listing_inspected_rows = 2

archive_member_rows_listed = 78

candidate_archive_member_rows = 34

exact_covariance_file_staged = false

full_covariance_available = false

full_covariance_values_loaded = false

covariance_dimension_confirmed = false

observed_row_order_matched = false

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: controlled official source download/archive-listing attempt only; archive members may be listed; no archive member contents parsed for covariance values; no covariance values loaded; no exact covariance file approved; no covariance dimensions confirmed; no observed-row order matched; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step attempts controlled download/archive listing only.

It does **not** read archive member contents.

It does **not** load covariance values.

It does **not** confirm covariance dimensions or observed-row order.

It does **not** compute likelihood or p-values.

It does **not** make support claims.

Next route: `human_fill_v4_377_archive_member_review_then_v4_378_archive_member_review_ingest_no_values_no_support_claims`
