# TAIRID SDSS/BOSS RSD Guarded Covariance-Corrected Diagnostic and Robustness Comparison

## Boundary

This packet is a cautious diagnostic writeup only. It summarizes previously audited dry-run diagnostics and robustness checks. It is not a likelihood result, not a p-value result, not a validated score, and not a support claim for TAIRID. The active boundary remains: `score_valid=false` and `support_allowed=false`.

## Data scope

The diagnostic remains narrow. It uses three BOSS DR12 combined-sample f_sigma8 residual rows at z=0.38, z=0.51, and z=0.61. It does not yet include eBOSS tracers, other surveys, a multi-survey covariance model, systematic-error propagation, or a full likelihood analysis.

## Primary diagnostic values

The prior guarded diagonal reference was:

```text
prior_guarded_diagonal_chi_square_sum = 1.362038876169214
```

The guarded covariance-corrected dry-run value using the human-approved dM_Hz_fsig covariance subblock was:

```text
primary_dM_Hz_chi_square_dry_run_sum = 1.384804886905097
```

The change from the prior diagonal diagnostic was:

```text
full_minus_diagonal_chi_square_difference = 0.022766010735883135
full_to_diagonal_chi_square_ratio = 1.0167146556050686
```

These values are diagnostic dry-run values only. They are not likelihoods, p-values, validated scores, or support claims.

## Robustness comparison

The robustness lane compared the primary dM_Hz_fsig covariance candidate with preserved alternate covariance candidates. The final-consensus dV_FAP_fsig candidate produced:

```text
final_consensus_dV_FAP_chi_square = 1.384804886905097
```

The FS_consensus fallback candidates produced the lower comparison value:

```text
fs_consensus_chi_square = 1.2298323467773977
```

Across the primary and alternate covariance candidates, the guarded chi-square dry-run band was:

```text
robustness_min_chi_square = 1.2298323467773977
robustness_max_chi_square = 1.384804886905097
robustness_chi_square_range_width = 0.15497254012769934
```

This narrow band is useful for checking that the covariance-repair path is not wildly unstable inside this specific three-row lane. It does not establish physical validation, broad generalization, or support for TAIRID.

## External audit status

Two external AI audits were ingested in v4.398B. Both passed with no corrections required. Both confirmed the truth boundary, the absence of improper support claims, the absence of likelihood and p-values, and the continued status of `score_valid=false` and `support_allowed=false`.

## Strongest honest conclusion

The strongest allowed conclusion is that a guarded covariance-corrected three-row BOSS DR12 f_sigma8 diagnostic and a small robustness comparison were completed, audited, and found internally consistent under their stated boundary. The primary covariance-corrected dry-run value was 1.384804886905097, and the robustness comparison stayed within the band 1.2298323467773977 to 1.384804886905097, with range width 0.15497254012769934. This is audit-clean as a narrow diagnostic, but it is not a support claim.

## Strongest honest criticism

The diagnostic is structurally local. It uses only three BOSS DR12 redshift rows, selected 3x3 covariance subblocks, and dry-run chi-square comparisons. It does not include a full likelihood, p-values, broader survey families, a multi-survey covariance model, systematic-error treatment, or cross-tracer validation. The narrowness of the robustness band shows consistency inside this bounded lane only.

## Next route

The clean next route is broader source expansion before any stronger scientific interpretation. A public-facing summary can be drafted from this packet only if it preserves the same boundary: no likelihood, no p-values, no validated score, and no support claim.
