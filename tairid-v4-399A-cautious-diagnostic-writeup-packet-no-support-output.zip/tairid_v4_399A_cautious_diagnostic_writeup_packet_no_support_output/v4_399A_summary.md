# TAIRID v4.399A Cautious Diagnostic Writeup Packet — No Support Claims

Expected result: `v4_399A_cautious_diagnostic_writeup_packet_created_no_support_claims`

49 / 49 rules passed

failed_gates = none

diagnostic_writeup_created = true

diagnostic_value_rows = 7

writeup_finding_rows = 6

writeup_section_rows = 6

forbidden_phrase_hits = 0

prior_guarded_diagonal_chi_square_sum = 1.362038876169214

primary_dM_Hz_chi_square_dry_run_sum = 1.384804886905097

final_consensus_dV_FAP_chi_square = 1.384804886905097

fs_consensus_chi_square = 1.2298323467773977

robustness_min_chi_square = 1.2298323467773977

robustness_max_chi_square = 1.384804886905097

robustness_chi_square_range_width = 0.15497254012769934

new_chi_square_computed = false

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: cautious diagnostic writeup packet only; previously audited covariance-corrected and robustness diagnostic values may be summarized; no new chi-square computed; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step creates cautious writeup materials only.

It does **not** compute a new chi-square.

It does **not** compute likelihood or p-values.

It does **not** validate score_valid.

It does **not** allow support claims.

Next route: `v4_400_broader_source_expansion_manifest_no_support_claims`
