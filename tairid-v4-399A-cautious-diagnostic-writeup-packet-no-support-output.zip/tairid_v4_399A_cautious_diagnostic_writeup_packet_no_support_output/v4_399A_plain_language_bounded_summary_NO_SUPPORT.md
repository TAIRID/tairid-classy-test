# Plain-language bounded summary

We have a real guarded diagnostic now, but not a claim that TAIRID is supported.

The earlier diagonal-only chi-square was 1.362038876169214. After using the repaired 3x3 f_sigma8 covariance subblock, the covariance-corrected dry-run chi-square was 1.384804886905097. The alternate covariance candidates kept the result inside a narrow band from 1.2298323467773977 to 1.384804886905097. That is useful because it means the result does not swing wildly when the preserved covariance candidates are changed inside this narrow test.

The boundary still matters. This is only three BOSS DR12 redshift rows. It is not a likelihood. It has no p-values. The score is not validated. Support claims remain blocked. The honest wording is: the covariance-repaired diagnostic is audit-clean and internally consistent inside a narrow lane, but broader data and stronger statistics are still needed before any larger scientific interpretation.
