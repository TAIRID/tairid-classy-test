# v4.369 Human-Filled Full Covariance Source Review for v4.370

Accepted current-lane covariance source candidates 001, 002, and 004 for later search/staging.
Candidate 003 is kept blocked for now because it belongs more naturally to a broader eBOSS/DR16 lane, not the current BOSS DR12 three-row repair.

No covariance file is uploaded here.
No covariance values are loaded.
No covariance dimensions or row order are confirmed.
No likelihood, p-values, score, or support claim is allowed.
