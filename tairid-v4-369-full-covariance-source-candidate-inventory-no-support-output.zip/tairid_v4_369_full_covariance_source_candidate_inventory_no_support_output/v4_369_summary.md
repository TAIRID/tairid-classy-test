# TAIRID v4.369 Full Covariance Source Candidate Inventory — No Support Claims

Expected result: `v4_369_full_covariance_source_candidate_inventory_passed_no_covariance_loaded_no_support_claims`

32 / 32 rules passed

failed_gates = none

selected_repair_lane = `full_covariance_repair_lane`

repo_covariance_candidate_rows = 237

seeded_covariance_source_candidate_rows = 4

full_covariance_available = false

full_covariance_values_loaded = false

covariance_dimension_confirmed = false

observed_row_order_matched = false

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: full covariance source candidate inventory only; no covariance values loaded; no full covariance available yet; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step inventories candidate paths for full covariance repair.

It does **not** load covariance values.

It does **not** confirm covariance dimensions or row order.

It does **not** compute likelihood or p-values.

It does **not** make support claims.

Next route: `human_fill_v4_369_covariance_source_review_then_v4_370_full_covariance_source_candidate_review_no_support_claims`
