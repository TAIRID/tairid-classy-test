# v4.415 Human-Filled Exact Source Selection

This human-filled packet selects exact eBOSS source members after v4.414 raw source capture.

Selected for controlled loading in v4.416:
- Primary: MultiTracer_PK_BAORSD_measurements.zip value/covariance members for LRG and ELG.
- Alternate/crosscheck: MultiTracer_CF_BAORSD_measurements.zip value/covariance members for combined ELG+LRG.

QSO covariance-aware exact member remains unresolved in this packet. No observed values or covariance values are loaded here. No chi-square, likelihood, p-values, score, or support claim is allowed.
