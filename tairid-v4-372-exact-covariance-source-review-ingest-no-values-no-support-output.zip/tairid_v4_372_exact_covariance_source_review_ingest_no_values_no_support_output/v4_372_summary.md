# TAIRID v4.372 Exact Covariance Source Review Ingest — No Values, No Support Claims

Expected result: `v4_372_exact_covariance_source_review_ingest_passed_web_source_search_needed_no_values_no_support_claims`

47 / 47 rules passed

failed_gates = none

review_ingest_rows = 29

web_source_search_needed_rows = 2

rejected_candidate_rows = 25

blocked_candidate_rows = 2

exact_source_selected_rows = 0

exact_covariance_file_approved = false

full_covariance_file_staged = false

full_covariance_available = false

full_covariance_values_loaded = false

covariance_dimension_confirmed = false

observed_row_order_matched = false

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: exact covariance source review ingest only; no exact covariance file staged; no covariance values loaded; no covariance dimensions confirmed; no row order matched; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step ingests the exact-source human review.

It does **not** approve an exact covariance file.

It does **not** stage or load covariance values.

It does **not** confirm covariance dimensions or observed-row order.

It does **not** compute likelihood or p-values.

It does **not** make support claims.

Next route: `v4_373_official_covariance_web_source_manifest_no_values_no_support_claims`
