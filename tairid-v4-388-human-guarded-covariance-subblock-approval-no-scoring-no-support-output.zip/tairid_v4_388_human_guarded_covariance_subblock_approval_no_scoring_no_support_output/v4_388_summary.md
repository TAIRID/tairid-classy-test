# TAIRID v4.388 Human Guarded Covariance Subblock Approval — No Scoring, No Support Claims

Expected result: `v4_388_human_guarded_covariance_subblock_approval_passed_one_subblock_selected_no_scoring_no_support_claims`

53 / 53 rules passed

failed_gates = none

human_choice_rows = 2

approved_guarded_subblock_rows = 1

comparison_only_subblock_rows = 1

approved_observable_family = `dM_Hz_fsig`

comparison_observable_family = `dV_FAP_fsig`

approved_subblock_value_rows = 9

dry_run_packet_rows = 1

full_covariance_chisq_allowed_next = true

chi_square_computed = false

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: human guarded covariance subblock approval only; one row-order-passed candidate subblock may be approved for a later full-covariance chi-square dry run; no chi-square computed now; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step approves one guarded covariance subblock for the next dry run only.

It does **not** compute chi-square.

It does **not** compute likelihood or p-values.

It does **not** validate a score.

It does **not** make support claims.

Next route: `v4_389_full_covariance_chi_square_dry_run_no_support_claims`
