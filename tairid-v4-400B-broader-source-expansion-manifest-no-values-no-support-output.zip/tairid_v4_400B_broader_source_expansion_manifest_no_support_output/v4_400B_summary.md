# TAIRID v4.400B Broader Source Expansion Manifest — No Values, No Support Claims

Expected result: `v4_400B_broader_source_expansion_manifest_passed_no_values_no_support_claims`

36 / 36 rules passed

failed_gates = none

broader_source_candidate_rows = 9

source_expansion_review_packet_rows = 8

current_anchor_rows = 1

eboss_tracer_candidate_rows = 3

low_redshift_anchor_candidate_rows = 2

independent_survey_candidate_rows = 3

prior_guarded_diagonal_chi_square_sum = 1.362038876169214

primary_dM_Hz_chi_square_dry_run_sum = 1.384804886905097

robustness_min_chi_square = 1.2298323467773977

robustness_max_chi_square = 1.384804886905097

robustness_chi_square_range_width = 0.15497254012769934

new_observed_values_loaded = false

covariance_values_loaded = false

new_chi_square_computed = false

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: broader source expansion manifest only; previously audited BOSS DR12 three-row diagnostic may be used as current anchor; no new observed values loaded; no covariance values loaded; no new chi-square computed; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step creates a broader-source expansion manifest only.

It does **not** load new observed values.

It does **not** load covariance values.

It does **not** compute a new chi-square.

It does **not** compute likelihood or p-values.

It does **not** make support claims.

Next route: `human_fill_v4_400B_source_expansion_review_then_v4_401_broader_source_expansion_review_ingest_no_values_no_support_claims`
