# v4.401 Summary

Expected result: `v4_401_broader_source_expansion_review_ingest_passed_eboss_lrg_elg_qso_selected_no_values_no_support_claims`

Rules passed: 44 / 44

Failed gates: none

Selected first expansion lane: eBOSS LRG / ELG / QSO.

No observed values, covariance values, chi-square, likelihood, p-values, validated score, or support claim are produced.
