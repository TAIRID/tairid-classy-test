# Human-filled v4.373 official covariance source review for v4.374

All seven official source candidates are accepted for later download/header staging review only.

No source file is downloaded here.
No exact covariance file is staged here.
No covariance values are loaded here.
No covariance dimension or observed-row order is confirmed here.
No likelihood, p-values, score, or support claim is allowed.
