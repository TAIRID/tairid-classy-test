# TAIRID v4.333 Parameter Source Context Fill Guide — No Scoring

Truth boundary: `no observed scoring; no parameter approval; no numeric baseline approval; no support claims`

This packet joins the accepted v4.332 source-candidate IDs back to the v4.324 source URLs and quote/context windows.

It does not approve parameter values, approve a numeric baseline, load observed SDSS RSD values, compute scores, or make support claims.

## param_q001 — omega_m0

Accepted candidate IDs: `parameter_source_candidate_001|parameter_source_candidate_016|parameter_source_candidate_004`

Source URLs: `https://arxiv.org/abs/1807.06209|https://arxiv.org/abs/2007.08991`

Human extraction task: Find the exact candidate numeric value text in the accepted source context. Do not approve it yet.

Source context blocks:

```text
parameter_source_candidate_001 :: https://arxiv.org/abs/1807.06209 :: 18 results. VI. Cosmological parameters, by Planck Collaboration: N. Aghanim and 180 other authors View PDF Abstract: We present cosmological parameter results from the final full-mission Planck measurements of the CMB anisotropies. We find good consistency with the standard spatially-flat 6-parameter $\Lambda$CDM cosmology having a power-law spectrum of adiabatic scalar perturbations (denoted "base $\Lambda$CDM" in this paper), from polarization, temperature, and lensing, separately and in combination. A combined analysis gives dark matter density $\Omega_c h^2 = 0.120\pm 0.001$, baryon density $\Omega_b h^2 = 0.0224\pm 0.0001$, scalar spectral index $n_s = 0.965\pm 0.004$, and optical depth $\tau = 0.054\pm 0.007$ (in this abstract we quote $68\,\%$ confidence regions on measured parameters and $95\,\%$ on upper limits). The angular acoustic scale is measured to $0.03\,\%$ precision, with $100\theta_*=1.0411\pm 0.0003$. These results are only weakly dependent on the cosmological model and remain stable, with somewhat increased errors, in many commonly considered
---
parameter_source_candidate_016 :: https://arxiv.org/abs/2007.08991 :: $, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of temperature and polarization the BAO data provide nearly an order of magnitude improvement on curvature constraints. The RSD measurements indicate a growth rate that is consistent with predictions from Planck primary data and with General Relativity. When combining the results of SDSS BAO and RSD with external data, all multiple-parameter extensions remain consistent with a $\Lambda$CDM model. Regardless of cosmological model, the precision on $\Omega_\Lambda$, $H_0$, and $\sigm
---
parameter_source_candidate_004 :: https://arxiv.org/abs/1807.06209 :: [1807.06209] Planck 2018 results. VI. Cosmological parameters Skip to main content Learn about arXiv becoming an independent nonprofit. We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors. Donate > astro-ph > arXiv:1807.06209 Help | Advanced Search All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text Search open search GO open navigation menu quick links Login Help Pages Abo
```

## param_q002 — sigma8_0

Accepted candidate IDs: `parameter_source_candidate_016|parameter_source_candidate_034|parameter_source_candidate_004`

Source URLs: `https://arxiv.org/abs/0704.0944|https://arxiv.org/abs/1807.06209|https://arxiv.org/abs/2007.08991`

Human extraction task: Find the exact candidate numeric value text in the accepted source context. Do not approve it yet.

Source context blocks:

```text
parameter_source_candidate_016 :: https://arxiv.org/abs/2007.08991 :: $, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of temperature and polarization the BAO data provide nearly an order of magnitude improvement on curvature constraints. The RSD measurements indicate a growth rate that is consistent with predictions from Planck primary data and with General Relativity. When combining the results of SDSS BAO and RSD with external data, all multiple-parameter extensions remain consistent with a $\Lambda$CDM model. Regardless of cosmological model, the precision on $\Omega_\Lambda$, $H_0$, and $\sigm
---
parameter_source_candidate_034 :: https://arxiv.org/abs/0704.0944 :: astro-ph > arXiv:0704.0944 Help | Advanced Search All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text Search GO quick links Login Help Pages About --> Astrophysics arXiv:0704.0944 (astro-ph) [Submitted on 7 Apr 2007] Title: GLAST and Dark Matter Substructure in the Milky Way Authors: Michael Kuhlen (1), Jürg Diemand (2), Piero Madau (2, 3) ((1) Institute for Advanced Study, Princeton, (2) UC Santa Cruz, (3) Max-Planck-Institut für Astrophysik, Garching, Germany) View a PDF of the paper titled GLAST and Dark Matter Substructure in the Milky Way, by Michael Kuhlen (1) and 7 other authors View PDF Abstract: We discuss the possibility of GLAST detecting gamma-rays from the annihilation of neutralino dark matter in the Galactic halo. We have used "Via Lactea", currently the highest resolution simulation of Galactic cold dark matter substructure, to quantify the contribution of subhalos to the annihilation signal. We present a simulated allsky map
---
parameter_source_candidate_004 :: https://arxiv.org/abs/1807.06209 :: [1807.06209] Planck 2018 results. VI. Cosmological parameters Skip to main content Learn about arXiv becoming an independent nonprofit. We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors. Donate > astro-ph > arXiv:1807.06209 Help | Advanced Search All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text Search open search GO open navigation menu quick links Login Help Pages Abo
```

## param_q003 — growth_index_gamma

Accepted candidate IDs: `parameter_source_candidate_012|parameter_source_candidate_015|parameter_source_candidate_018`

Source URLs: `https://arxiv.org/abs/1807.06210|https://arxiv.org/abs/2007.08991`

Human extraction task: Find the exact candidate numeric value text in the accepted source context. Do not approve it yet.

Source context blocks:

```text
parameter_source_candidate_012 :: https://arxiv.org/abs/1807.06210 :: llaboration: N. Aghanim and 156 other authors View PDF Abstract: We present measurements of the cosmic microwave background (CMB) lensing potential using the final $\textit{Planck}$ 2018 temperature and polarization data. We increase the significance of the detection of lensing in the polarization maps from $5\,\sigma$ to $9\,\sigma$. Combined with temperature, lensing is detected at $40\,\sigma$. We present an extensive set of tests of the robustness of the lensing-potential power spectrum, and construct a minimum-variance estimator likelihood over lensing multipoles $8 \le L \le 400$. We find good consistency between lensing constraints and the results from the $\textit{Planck}$ CMB power spectra within the $\rm{\Lambda CDM}$ model. Combined with baryon density and other weak priors, the lensing analysis alone constrains $\sigma_8 \Omega_{\rm m}^{0.25}=0.589\pm 0.020$ ($1\,\sigma$ errors). Also combining with baryon acoustic oscillation (BAO) data, we find tight individual parameter constraints, $\sigma_8=0.811\pm0.019$, $H_0=67.9_{-1.3}^{+1.2}\,\text{km}\,\text
---
parameter_source_candidate_015 :: https://arxiv.org/abs/2007.08991 :: l) Abstract: We present the cosmological implications from final measurements of clustering using galaxies, quasars, and Ly$\alpha$ forests from the completed Sloan Digital Sky Survey (SDSS) lineage of experiments in large-scale structure. These experiments, composed of data from SDSS, SDSS-II, BOSS, and eBOSS, offer independent measurements of baryon acoustic oscillation (BAO) measurements of angular-diameter distances and Hubble distances relative to the sound horizon, $r_d$, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of tem
---
parameter_source_candidate_018 :: https://arxiv.org/abs/2007.08991 :: he most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of temperature and polarization the BAO data provide nearly an order of magnitude improvement on curvature constraints. The RSD measurements indicate a growth rate that is consistent with predictions from Planck primary data and with General Relativity. When combining the results of SDSS BAO and RSD with external data, all multiple-parameter extensions remain consistent with a $\Lambda$CDM model. Regardless of cosmological model, the precision on $\Omega_\Lambda$, $H_0$, and $\sigma_8$, remains at roughly 1\%, showing changes of less than 0.6\% in the central values between models. The inverse distance ladder measurement under a o$w_0w_a$C
```

## param_q004 — lcdm_calculator_context

Accepted candidate IDs: `parameter_source_candidate_015|parameter_source_candidate_016|parameter_source_candidate_004`

Source URLs: `https://arxiv.org/abs/1807.06209|https://arxiv.org/abs/2007.08991`

Human extraction task: Find the exact method or policy context text. Do not approve it as a numeric value.

Source context blocks:

```text
parameter_source_candidate_015 :: https://arxiv.org/abs/2007.08991 :: l) Abstract: We present the cosmological implications from final measurements of clustering using galaxies, quasars, and Ly$\alpha$ forests from the completed Sloan Digital Sky Survey (SDSS) lineage of experiments in large-scale structure. These experiments, composed of data from SDSS, SDSS-II, BOSS, and eBOSS, offer independent measurements of baryon acoustic oscillation (BAO) measurements of angular-diameter distances and Hubble distances relative to the sound horizon, $r_d$, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of tem
---
parameter_source_candidate_016 :: https://arxiv.org/abs/2007.08991 :: $, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of temperature and polarization the BAO data provide nearly an order of magnitude improvement on curvature constraints. The RSD measurements indicate a growth rate that is consistent with predictions from Planck primary data and with General Relativity. When combining the results of SDSS BAO and RSD with external data, all multiple-parameter extensions remain consistent with a $\Lambda$CDM model. Regardless of cosmological model, the precision on $\Omega_\Lambda$, $H_0$, and $\sigm
---
parameter_source_candidate_004 :: https://arxiv.org/abs/1807.06209 :: [1807.06209] Planck 2018 results. VI. Cosmological parameters Skip to main content Learn about arXiv becoming an independent nonprofit. We gratefully acknowledge support from the Simons Foundation, member institutions , and all contributors. Donate > astro-ph > arXiv:1807.06209 Help | Advanced Search All fields Title Author Abstract Comments Journal reference ACM classification MSC classification Report number arXiv identifier DOI ORCID arXiv author ID Help pages Full text Search open search GO open navigation menu quick links Login Help Pages Abo
```

## param_q005 — rsd_definition_bridge

Accepted candidate IDs: `parameter_source_candidate_015|parameter_source_candidate_017|parameter_source_candidate_033`

Source URLs: `https://arxiv.org/abs/0704.0944|https://arxiv.org/abs/2007.08991`

Human extraction task: Find the exact method or policy context text. Do not approve it as a numeric value.

Source context blocks:

```text
parameter_source_candidate_015 :: https://arxiv.org/abs/2007.08991 :: l) Abstract: We present the cosmological implications from final measurements of clustering using galaxies, quasars, and Ly$\alpha$ forests from the completed Sloan Digital Sky Survey (SDSS) lineage of experiments in large-scale structure. These experiments, composed of data from SDSS, SDSS-II, BOSS, and eBOSS, offer independent measurements of baryon acoustic oscillation (BAO) measurements of angular-diameter distances and Hubble distances relative to the sound horizon, $r_d$, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of tem
---
parameter_source_candidate_017 :: https://arxiv.org/abs/2007.08991 :: implications from final measurements of clustering using galaxies, quasars, and Ly$\alpha$ forests from the completed Sloan Digital Sky Survey (SDSS) lineage of experiments in large-scale structure. These experiments, composed of data from SDSS, SDSS-II, BOSS, and eBOSS, offer independent measurements of baryon acoustic oscillation (BAO) measurements of angular-diameter distances and Hubble distances relative to the sound horizon, $r_d$, from eight different samples and six measurements of the growth rate parameter, $f\sigma_8$, from redshift-space distortions (RSD). This composite sample is the most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of temperature and polarization the BAO data pr
---
parameter_source_candidate_033 :: https://arxiv.org/abs/0704.0944 :: links Login Help Pages About --> Astrophysics arXiv:0704.0944 (astro-ph) [Submitted on 7 Apr 2007] Title: GLAST and Dark Matter Substructure in the Milky Way Authors: Michael Kuhlen (1), Jürg Diemand (2), Piero Madau (2, 3) ((1) Institute for Advanced Study, Princeton, (2) UC Santa Cruz, (3) Max-Planck-Institut für Astrophysik, Garching, Germany) View a PDF of the paper titled GLAST and Dark Matter Substructure in the Milky Way, by Michael Kuhlen (1) and 7 other authors View PDF Abstract: We discuss the possibility of GLAST detecting gamma-rays from the annihilation of neutralino dark matter in the Galactic halo. We have used "Via Lactea", currently the highest resolution simulation of Galactic cold dark matter substructure, to quantify the contribution of subhalos to the annihilation signal. We present a simulated allsky map of the expected gamma-ray counts from dark matter annihilation, assuming standard values of particle mass and cross section. In this case GLAST should be able to detect the Galactic center and several individual subhalos. Comments: 4 pages, 2
```

## param_q006 — calculator_limit_policy

Accepted candidate IDs: `parameter_source_candidate_012|parameter_source_candidate_018|parameter_source_candidate_042`

Source URLs: `https://arxiv.org/abs/1807.06210|https://arxiv.org/abs/2007.08991|https://www.sdss4.org/science/final-bao-and-rsd-measurements/`

Human extraction task: Find the exact method or policy context text. Do not approve it as a numeric value.

Source context blocks:

```text
parameter_source_candidate_012 :: https://arxiv.org/abs/1807.06210 :: llaboration: N. Aghanim and 156 other authors View PDF Abstract: We present measurements of the cosmic microwave background (CMB) lensing potential using the final $\textit{Planck}$ 2018 temperature and polarization data. We increase the significance of the detection of lensing in the polarization maps from $5\,\sigma$ to $9\,\sigma$. Combined with temperature, lensing is detected at $40\,\sigma$. We present an extensive set of tests of the robustness of the lensing-potential power spectrum, and construct a minimum-variance estimator likelihood over lensing multipoles $8 \le L \le 400$. We find good consistency between lensing constraints and the results from the $\textit{Planck}$ CMB power spectra within the $\rm{\Lambda CDM}$ model. Combined with baryon density and other weak priors, the lensing analysis alone constrains $\sigma_8 \Omega_{\rm m}^{0.25}=0.589\pm 0.020$ ($1\,\sigma$ errors). Also combining with baryon acoustic oscillation (BAO) data, we find tight individual parameter constraints, $\sigma_8=0.811\pm0.019$, $H_0=67.9_{-1.3}^{+1.2}\,\text{km}\,\text
---
parameter_source_candidate_018 :: https://arxiv.org/abs/2007.08991 :: he most constraining of its kind and allows us to perform a comprehensive assessment of the cosmological model after two decades of dedicated spectroscopic observation. We show that the BAO data alone are able to rule out dark-energy-free models at more than eight standard deviations in an extension to the flat, $\Lambda$CDM model that allows for curvature. When combined with Planck Cosmic Microwave Background (CMB) measurements of temperature and polarization the BAO data provide nearly an order of magnitude improvement on curvature constraints. The RSD measurements indicate a growth rate that is consistent with predictions from Planck primary data and with General Relativity. When combining the results of SDSS BAO and RSD with external data, all multiple-parameter extensions remain consistent with a $\Lambda$CDM model. Regardless of cosmological model, the precision on $\Omega_\Lambda$, $H_0$, and $\sigma_8$, remains at roughly 1\%, showing changes of less than 0.6\% in the central values between models. The inverse distance ladder measurement under a o$w_0w_a$C
---
parameter_source_candidate_042 :: https://www.sdss4.org/science/final-bao-and-rsd-measurements/ :: t were installed at the 2.5 meter Sloan Telescope in 2009. The BOSS design and survey strategy are described in the 2009-2014 BOSS overview while the eBOSS scientific justification and survey plan are described in the 2014-2019 eBOSS overview . Key to the BAO and RSD measurements in SDSS, BOSS, and eBOSS are advanced processing of imaging data, carefully crafted target selection, well vetted catalogs of redshifts, weights, and randoms, clustering analysis, and assessment of statistical and systematic errors through mock catalogs. The likelihoods, covariance matrices, and cosmoMC chains with the SDSS data can be found here . The background of these measurements for each of the SDSS cosmology samples can be found in the table below. The table below may be cut off in your browser, so we also have a full-width version of the table . Parameter Main Galaxy Sample (MGS) BOSS Galaxy BOSS Galaxy eBOSS LRG eBOSS ELG eBOSS Quasar Lyα-Lyα Lyα-Quasar Imaging, Target Selection, and Spectroscopic Properties of Each Sample Imaging for Target Selection SDSS SDSS SDSS SDSS + WISE D
```
