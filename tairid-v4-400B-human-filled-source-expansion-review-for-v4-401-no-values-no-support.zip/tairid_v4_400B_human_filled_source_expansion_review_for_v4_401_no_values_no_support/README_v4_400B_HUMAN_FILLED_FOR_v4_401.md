# v4.400B Human-Filled Source Expansion Review for v4.401

Approved now for source inventory only:

- eBOSS LRG fsigma8 expansion
- eBOSS ELG fsigma8 expansion
- eBOSS QSO fsigma8 expansion

Deferred until later:

- WiggleZ
- 6dFGS
- SDSS MGS
- VIPERS
- GAMA

No observed values are loaded. No covariance values are loaded. No chi-square, likelihood, p-values, validated score, or support claim is produced.
