# TAIRID v4.396B Alternate Full-Covariance Chi-Square Dry-Run Comparison — No Support Claims

Expected result: `v4_396B_alternate_full_covariance_chi_square_dry_run_comparison_passed_no_likelihood_no_p_values_no_support_claims`

52 / 52 rules passed

failed_gates = none

primary_dM_Hz_chi_square_dry_run_sum = 1.384804886905097

prior_guarded_diagonal_chi_square_sum = 1.362038876169214

alternate_chi_square_rows = 3

alternate_chi_square_term_rows = 9

primary_plus_alternate_comparison_rows = 4

robustness_min_chi_square = 1.2298323467773977

robustness_max_chi_square = 1.384804886905097

robustness_chi_square_range_width = 0.15497254012769934

final_consensus_dV_FAP_chi_square = 1.384804886905097

fs_consensus_chi_square = 1.2298323467773977

new_chi_square_computed = true

alternate_chi_square_computed = true

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: alternate full-covariance chi-square dry-run robustness comparison only; alternate 3x3 f_sigma8 covariance subblocks may be used for chi-square comparison; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step computes alternate covariance chi-square dry-run comparisons only.

It does **not** compute likelihood or p-values.

It does **not** validate a score.

It does **not** make support claims.

Next route: `v4_397B_robustness_external_audit_packet_no_support_claims`
