Human-filled guarded covariance subblock choice for v4.388. One dM_Hz_fsig final-consensus subblock approved for dry-run staging only; dV_FAP_fsig kept as comparison. No scoring or support claims.
