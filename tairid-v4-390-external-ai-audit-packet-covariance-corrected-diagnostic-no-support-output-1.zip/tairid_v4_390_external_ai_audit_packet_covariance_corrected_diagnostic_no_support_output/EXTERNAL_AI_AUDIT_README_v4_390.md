# External AI Audit Packet — TAIRID SDSS/BOSS RSD v4.390

## Truth boundary

external AI audit packet for covariance-corrected diagnostic only; full-covariance chi-square dry-run may be audited; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims

## Strongest allowed conclusion

A covariance-corrected chi-square dry run was computed for the three BOSS DR12 f_sigma8 residual rows using the human-approved dM_Hz_fsig 3x3 covariance subblock. The dry-run value is 1.384804886905097, compared with the prior guarded diagonal value 1.362038876169214. The result is audit-ready, but it is not a likelihood, not a p-value, not a validated score, and not a support claim.

## Strongest honest criticism

This remains a guarded three-row diagnostic. It uses a selected 3x3 covariance subblock rather than a full likelihood or broader survey covariance model, computes no p-values, keeps score_valid=false, and cannot support TAIRID claims before external audit and later interpretation/robustness gates.

## Key numbers to audit

- prior_guarded_diagonal_chi_square_sum = 1.362038876169214
- full_covariance_chi_square_dry_run_sum = 1.384804886905097
- full_minus_diagonal_chi_square_difference = 0.022766010735883135
- full_to_diagonal_chi_square_ratio = 1.0167146556050686
- degrees_of_freedom_candidate = 3
- covariance_determinant = 1.9412585563062905e-09
- covariance_condition_number = 5.269139586406335
- minimum_covariance_eigenvalue = 0.0005357088134123415

## Audit instructions

External AI should check whether the packet preserves the truth boundary, whether the v4.389 values match the preserved evidence files, whether any support claim is made, whether likelihood or p-values were computed, and whether the result is correctly limited to a covariance-corrected chi-square dry run.

## Required evidence files

See `v4_390_audit_file_manifest.csv`.

## Next honest gate

External AI audit should be completed before any interpretation gate. After audit, the next route should be either an audit-response ingest, a cautious interpretation gate, or a robustness/comparison lane using preserved covariance candidates. No support claim should be made from v4.390.
