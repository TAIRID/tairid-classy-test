# TAIRID v4.390 External AI Audit Packet — Covariance-Corrected Diagnostic, No Support Claims

Expected result: `v4_390_external_ai_audit_packet_created_for_covariance_corrected_diagnostic_no_support_claims`

49 / 49 rules passed

failed_gates = none

prior_guarded_diagonal_chi_square_sum = 1.362038876169214

full_covariance_chi_square_dry_run_sum = 1.384804886905097

full_minus_diagonal_chi_square_difference = 0.022766010735883135

full_to_diagonal_chi_square_ratio = 1.0167146556050686

approved_observable_family = `dM_Hz_fsig`

approved_subblock_value_rows = 9

residual_vector_rows = 3

degrees_of_freedom_candidate = 3

covariance_subblock_values_loaded = true

full_9x9_covariance_values_loaded = false

full_covariance_chi_square_computed = true

chi_square_computed = true

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: external AI audit packet for covariance-corrected diagnostic only; full-covariance chi-square dry-run may be audited; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step creates the external AI audit packet for the covariance-corrected diagnostic.

It does **not** compute likelihood or p-values.

It does **not** validate a score.

It does **not** make support claims.

Next route: `external_ai_audit_then_v4_391_audit_response_ingest_or_cautious_interpretation_gate_no_support_claims`
