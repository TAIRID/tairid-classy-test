# TAIRID v4.385 Controlled Covariance Subblock Extraction Dry Run — No Scoring, No Support Claims

Expected result: `v4_385_controlled_covariance_subblock_extraction_dry_run_passed_candidate_subblocks_extracted_no_scoring_no_support_claims`

48 / 48 rules passed

failed_gates = none

controlled_extraction_packet_rows = 2

official_archive_downloaded = true

candidate_subblocks_extracted = 2

candidate_subblock_value_rows = 18

candidate_subblock_matrix_rows = 6

integrity_staging_packet_rows = 2

covariance_subblock_extracted = true

candidate_subblock_values_extracted = true

full_covariance_matrix_loaded = false

full_covariance_available = false

full_covariance_values_loaded = false

covariance_dimension_confirmed = false

observed_row_order_matched = false

likelihood_computed = false

p_values_computed = false

chi_square_computed = false

score_valid = false

support_allowed = false

Claim boundary: controlled covariance subblock extraction dry run only; candidate 3x3 f_sigma8 subblock values may be extracted for later integrity checks; no chi-square; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step performs controlled candidate 3x3 f_sigma8 subblock extraction only.

It does **not** run integrity acceptance.

It does **not** validate observed-row order.

It does **not** compute chi-square, likelihood, or p-values.

It does **not** make support claims.

Next route: `v4_386_covariance_subblock_integrity_checks_no_scoring_no_support_claims`
