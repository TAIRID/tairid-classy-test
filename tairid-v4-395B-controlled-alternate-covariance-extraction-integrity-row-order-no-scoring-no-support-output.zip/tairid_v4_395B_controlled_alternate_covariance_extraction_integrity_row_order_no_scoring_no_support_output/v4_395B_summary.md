# TAIRID v4.395B Controlled Alternate Covariance Extraction, Integrity, and Row-Order Validation — No Scoring, No Support Claims

Expected result: `v4_395B_controlled_alternate_covariance_extraction_integrity_row_order_passed_comparison_ready_no_scoring_no_support_claims`

63 / 63 rules passed

failed_gates = none

controlled_alternate_extraction_rows = 3

official_archive_downloaded = true

alternate_subblocks_extracted = 3

alternate_subblock_value_rows = 27

alternate_subblock_matrix_rows = 9

integrity_checked_subblocks = 3

integrity_passed_subblocks = 3

row_order_detail_rows = 27

row_order_passed_subblocks = 3

comparison_ready_rows = 3

all_shapes_3x3 = true

all_finite_entries = true

all_symmetric_within_tolerance = true

all_diagonal_positive = true

all_psd_candidate_within_tolerance = true

new_chi_square_computed = false

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: controlled alternate covariance extraction, integrity checks, and row-order validation only; alternate candidate 3x3 f_sigma8 covariance subblock values may be extracted for robustness comparison; no chi-square; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step performs controlled alternate covariance extraction, integrity checks, and row-order validation only.

It does **not** compute chi-square.

It does **not** compute likelihood or p-values.

It does **not** validate a score.

It does **not** make support claims.

Next route: `v4_396B_alternate_full_covariance_chi_square_dry_run_comparison_no_support_claims`
