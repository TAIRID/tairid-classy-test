# TAIRID v4.365 Guarded Diagonal Chi-Square Dry Run — No Likelihood, No P-Values, No Support

Expected result: `v4_365_guarded_diagonal_chi_square_dry_run_passed_chi_square_computed_no_likelihood_no_p_values_no_support`

33 / 33 rules passed

failed_gates = none

readiness_status = `guarded_diagonal_chi_square_computed_no_likelihood_no_p_values_no_support`

human_chi_square_dry_run_input = `yes`

chi_square_computed = True

guarded_diagonal_chi_square_sum = 1.362038876169214

degrees_of_freedom_candidate = 3

likelihood_computed = false

p_values_computed = false

full_covariance_available = false

score_valid = false

support_allowed = false

Claim boundary: parameter values approved; numeric baseline approved; observed values loaded; definition/covariance guarded readiness confirmed; baseline predictions computed; residuals approved; guarded diagonal chi-square may be dry-run computed here; no likelihood; no p-values; no full covariance; score_valid remains false; no support claims.

This step computes guarded diagonal chi-square only when the human input is `yes`.

It does **not** compute likelihood.

It does **not** compute p-values.

It does **not** use full covariance.

It does **not** create a general valid score.

It does **not** make support claims.

Next route: `v4_366_guarded_chi_square_diagnostic_review_no_support_claims`
