# v4.365 Human-Filled Guarded Chi-Square Diagnostic Review for v4.366

Decision: approve_guarded_chi_square_diagnostic_for_external_audit

Boundary preserved:
- No full covariance.
- No likelihood.
- No p-values.
- score_valid remains false.
- support_allowed remains false.
- This is for external-audit preparation only, not a support claim.
