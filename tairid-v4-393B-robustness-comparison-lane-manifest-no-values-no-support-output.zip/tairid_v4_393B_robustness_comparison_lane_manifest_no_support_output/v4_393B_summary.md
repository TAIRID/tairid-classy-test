# TAIRID v4.393B Robustness Comparison Lane Manifest — No Values, No Support Claims

Expected result: `v4_393B_robustness_comparison_lane_manifest_passed_no_values_no_support_claims`

41 / 41 rules passed

failed_gates = none

robustness_candidate_rows = 3

final_consensus_alternate_rows = 1

fs_consensus_fallback_rows = 2

human_review_packet_rows = 3

prior_guarded_diagonal_chi_square_sum = 1.362038876169214

full_covariance_chi_square_dry_run_sum = 1.384804886905097

full_minus_diagonal_chi_square_difference = 0.022766010735883135

full_to_diagonal_chi_square_ratio = 1.0167146556050686

new_chi_square_computed = false

covariance_values_loaded = false

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: robustness comparison lane manifest only; alternate covariance candidates may be listed for later review; no covariance values loaded; no new chi-square; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step creates a robustness comparison lane manifest only.

It does **not** load alternate covariance values.

It does **not** compute a new chi-square.

It does **not** compute likelihood or p-values.

It does **not** make support claims.

Next route: `human_fill_v4_393B_robustness_candidate_review_then_v4_394B_robustness_candidate_review_ingest_no_values_no_support_claims`
