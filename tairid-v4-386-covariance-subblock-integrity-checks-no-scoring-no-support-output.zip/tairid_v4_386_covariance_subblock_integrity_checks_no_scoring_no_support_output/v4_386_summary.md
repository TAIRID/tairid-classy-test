# TAIRID v4.386 Covariance Subblock Integrity Checks — No Scoring, No Support Claims

Expected result: `v4_386_covariance_subblock_integrity_checks_passed_ready_for_row_order_validation_no_scoring_no_support_claims`

50 / 50 rules passed

failed_gates = none

candidate_subblocks_checked = 2

integrity_passed_subblocks = 2

integrity_failed_subblocks = 0

row_order_staging_packet_rows = 2

all_shapes_3x3 = true

all_finite_entries = true

all_symmetric_within_tolerance = true

all_diagonal_positive = true

all_psd_candidate_within_tolerance = true

full_covariance_matrix_loaded = false

full_covariance_available = false

full_covariance_values_loaded = false

observed_row_order_matched = false

chi_square_computed = false

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: covariance subblock integrity checks only; candidate 3x3 f_sigma8 subblock values may be checked for shape, finite entries, symmetry, positive diagonal, and PSD-candidate behavior; no chi-square; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step checks candidate 3x3 f_sigma8 subblock integrity only.

It does **not** validate observed-row order.

It does **not** compute chi-square, likelihood, or p-values.

It does **not** make support claims.

Next route: `v4_387_observed_row_order_validation_no_scoring_no_support_claims`
