# TAIRID v4.334 Human Parameter-Value Extraction Worksheet — No Scoring

Truth boundary:

`no observed scoring; no parameter approval; no numeric baseline approval; no support claims`

This worksheet is for extracting exact source text only.

Do not approve values in this step.

Do not approve a numeric baseline in this step.

Do not load observed SDSS RSD values in this step.

Do not compute residuals, chi-square, likelihood, p-values, or model scores in this step.

Do not make support claims.

## What the human reviewer should fill

For each row in `v4_334_HUMAN_FILL_parameter_value_extraction_worksheet_NO_APPROVAL_NO_SCORING.csv`, fill only:

```text
human_exact_quote_selected
human_source_url_for_selected_quote
human_source_page_section_or_table
human_candidate_value_text_as_written
human_candidate_numeric_value_if_applicable
human_candidate_uncertainty_if_applicable
human_candidate_units_or_definition
human_context_note
human_extraction_decision
human_reviewer_note
```

Allowed decisions:

```text
extract_candidate_for_later_value_review
needs_exact_quote
needs_better_source
context_only_not_value
reject_candidate
keep_blocked
```

This step prepares extraction. It does not accept the extracted values as approved.
