Human-filled v4.358 definition/covariance review for v4.359.

Decision scope:
- Definition match accepted for later scoring-readiness review only.
- Diagonal error model accepted only for guarded diagnostic readiness.
- Full covariance / full likelihood / support claims remain blocked.
- No residuals, chi-square, likelihood, p-values, scores, or support claims are created here.
