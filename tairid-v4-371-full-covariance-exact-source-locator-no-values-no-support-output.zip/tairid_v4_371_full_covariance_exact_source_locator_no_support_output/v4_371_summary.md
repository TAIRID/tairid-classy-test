# TAIRID v4.371 Full Covariance Exact Source Locator — No Values, No Support Claims

Expected result: `v4_371_full_covariance_exact_source_locator_passed_no_exact_file_approved_no_values_no_support_claims`

40 / 40 rules passed

failed_gates = none

accepted_source_directions = 3

repo_ranked_candidate_rows = 237

top_repo_candidate_rows = 25

locator_packet_rows = 29

exact_covariance_file_approved = false

full_covariance_file_staged = false

full_covariance_available = false

full_covariance_values_loaded = false

covariance_dimension_confirmed = false

observed_row_order_matched = false

likelihood_computed = false

p_values_computed = false

score_valid = false

support_allowed = false

Claim boundary: exact covariance source locator/staging packet only; no exact covariance file approved; no covariance values loaded; no covariance dimensions confirmed; no row order matched; no likelihood; no p-values; score_valid remains false; support_allowed remains false; no support claims.

This step creates an exact-source locator and human review packet.

It does **not** approve an exact covariance file.

It does **not** stage or load covariance values.

It does **not** confirm covariance dimensions or observed-row order.

It does **not** compute likelihood or p-values.

It does **not** make support claims.

Next route: `human_fill_v4_371_exact_source_review_then_v4_372_exact_covariance_source_review_ingest_no_values_no_support_claims`
